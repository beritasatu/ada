---
title: "contoh jurnal qualitative research pdf"
description: "Imrad examples / imrad format example pdf contoh makalah : many"
date: "2022-08-27"
categories:
- "ada"
images:
- "https://lh3.googleusercontent.com/proxy/DujJP_XZ8Tvw1Jh-3kYwbx__vJFwjI8LZYiCuYVqoUU_RDDz1uAX2bGkCLkKf4a7Jn9kMASAz0SMszd9ri1u_xcQw3SjUByPBgvklEs0V30ErzcYlFhWknxVAoTZtbk=s0-d"
featuredImage: "https://lh4.googleusercontent.com/proxy/gyznopFZuk35RHQXWRHl1oKE1p3szBenp1bdIptlRqEE4XTiRs--t2mhxmE-KFn4EVGqUFqfwu3Dn77Y_omQQ8ayLXKjgQGeHhAqwaaNjfc-57J6iWCv1sACGT4MbmJ8nlLr1SLT1wsCHexu0pVnMaTyWf4=s0-d"
featured_image: "https://lh4.googleusercontent.com/proxy/gyznopFZuk35RHQXWRHl1oKE1p3szBenp1bdIptlRqEE4XTiRs--t2mhxmE-KFn4EVGqUFqfwu3Dn77Y_omQQ8ayLXKjgQGeHhAqwaaNjfc-57J6iWCv1sACGT4MbmJ8nlLr1SLT1wsCHexu0pVnMaTyWf4=s0-d"
image: "https://cdn.slidesharecdn.com/ss_thumbnails/reviewjurnalintervensiperson-151125134354-lva1-app6892-thumbnail-4.jpg?cb=1448459101"
---

If you are searching about (PDF) PEMAHAMAN MAHASISWA ATAS METODE PENELITIAN KUALITATIF: SEBUAH you've visit to the right place. We have 35 Images about (PDF) PEMAHAMAN MAHASISWA ATAS METODE PENELITIAN KUALITATIF: SEBUAH like Contoh Jurnal Qualitative Research Pdf - Hot Press New York City, Contoh Jurnal HI - Prodi Ilmu Hubungan Internasional and also Contoh Jurnal Qualitative Research - Lowongan Kerja Terbaru. Here you go:

## (PDF) PEMAHAMAN MAHASISWA ATAS METODE PENELITIAN KUALITATIF: SEBUAH

![(PDF) PEMAHAMAN MAHASISWA ATAS METODE PENELITIAN KUALITATIF: SEBUAH](https://i1.rgstatic.net/publication/283435881_PEMAHAMAN_MAHASISWA_ATAS_METODE_PENELITIAN_KUALITATIF_SEBUAH_REFLEKSI_ARTIKEL_HASIL_PENELITIAN/links/56de207608aedf2bf0c873ad/largepreview.png "Qualitative quantitative exploratory proposal")

<small>www.researchgate.net</small>

Contoh jurnal akuntansi pdf. Contoh jurnal qualitative research

## Imrad Examples / Imrad Format Example Pdf Contoh Makalah : Many

![Imrad Examples / Imrad Format Example Pdf Contoh Makalah : Many](https://www.museumlegs.com/g/006-example-of-research-paper-pdf-qualitative-and-quantitative-examples-129961-858x1111.png "Contoh proposal qualitative research pendidikan bahasa inggris")

<small>best-hot-news-23.blogspot.com</small>

Contoh proposal qualitative research. Contoh jurnal qualitative research pdf

## Jurnal Bahasa Inggris Tentang Informatika 2017 | Link Guru

![Jurnal Bahasa Inggris Tentang Informatika 2017 | Link Guru](https://0.academia-photos.com/attachment_thumbnails/37565413/mini_magick20180818-26504-1m6mnzc.png?1534604408 "Aspek haeri menelaah")

<small>www.linkguru.net</small>

Contoh qualitative jurnal cybercrime. Contoh jurnal qualitative research pdf

## 32+ Contoh Review Jurnal Pendidikan Inklusi Pictures - Administrasi

![32+ Contoh Review Jurnal Pendidikan Inklusi Pictures - Administrasi](https://cdn.slidesharecdn.com/ss_thumbnails/reviewjurnalintervensiperson-151125134354-lva1-app6892-thumbnail-4.jpg?cb=1448459101 "Penelitian kualitatif pdf contoh")

<small>administrasigurusdsmpsma.blogspot.com</small>

Quantitative qualitative jurnal. Proposal dissertation skripsi

## Contoh Jurnal HI - Prodi Ilmu Hubungan Internasional

![Contoh Jurnal HI - Prodi Ilmu Hubungan Internasional](https://s1.studylibid.com/store/data/000192420_1-0aad40fcb6ceb1525f123dea1ec8d088.png "Qualitative quantitative exploratory proposal")

<small>studylibid.com</small>

Kasim jurnal qualitative. 32+ contoh review jurnal pendidikan inklusi pictures

## Contoh Jurnal Penelitian Pemodelan Forecasting : Download Jurnal

![Contoh Jurnal Penelitian Pemodelan Forecasting : Download Jurnal](https://image.slidesharecdn.com/dmydocumentsblog1041-suhartono-statistics-modelintevensipulsefunction-090902021739-phpapp02/95/jurnal-time-series-model-intervensi-11-728.jpg?cb=1251857865 "Contoh jurnal akuntansi pdf")

<small>produkpowerpoint.blogspot.com</small>

Jurnal bahasa inggris tentang informatika 2017. Jurnal mamikos inovasi budaya

## Contoh Jurnal Qualitative Research Pdf - Contoh Grim

![Contoh Jurnal Qualitative Research Pdf - Contoh Grim](https://lh4.googleusercontent.com/proxy/gyznopFZuk35RHQXWRHl1oKE1p3szBenp1bdIptlRqEE4XTiRs--t2mhxmE-KFn4EVGqUFqfwu3Dn77Y_omQQ8ayLXKjgQGeHhAqwaaNjfc-57J6iWCv1sACGT4MbmJ8nlLr1SLT1wsCHexu0pVnMaTyWf4=s0-d "Contoh literature review proposal skripsi")

<small>contohgrim.blogspot.com</small>

42+ contoh jurnal inovasi pendidikan budaya pics. Cerpen diksi karya rangkuti kesetiaan materi sma

## Contoh Jurnal Bahasa Inggris Tentang Reading Pdf – Berbagai Contoh

![Contoh Jurnal Bahasa Inggris Tentang Reading Pdf – Berbagai Contoh](https://0.academia-photos.com/attachment_thumbnails/52540753/mini_magick20180819-20256-gcuud8.png?1534698208 "Contoh proposal qualitative research pendidikan bahasa inggris")

<small>berbagaicontoh.com</small>

Penelitian kualitatif pdf contoh. Contoh qualitative jurnal cybercrime

## (PDF) Jurnal Komunikasi

![(PDF) Jurnal Komunikasi](https://i1.rgstatic.net/publication/327883730_Jurnal_Komunikasi/links/5bab37a545851574f7e6534c/largepreview.png "Jurnal komunikasi")

<small>www.researchgate.net</small>

Contoh jurnal penelitian pemodelan forecasting : download jurnal. Methodology qualitative quantitative dissertation ihelptostudy hypothesis brojsimpson

## Contoh Jurnal Qualitative Research Pdf - Hot Press New York City

![Contoh Jurnal Qualitative Research Pdf - Hot Press New York City](https://lh6.googleusercontent.com/proxy/5_LhAtZI-rw68ZKvI2gqN1MxQ9pwbxPAvwod2DVhyRrmH-l2curDm-KBQKEPQ5ligwnCvqJUCWPZ0fTQDtg594LU4fIJTWPPKf6FTXESZyiq6jut3118p_9qlxaXu8L-FEQdJ76Kpr76Y93TfHU5DAFnL7YFauvym_sFHkj15fzHCUHQb2Ak5-QJ9JXFTTUcBCcmC4ubXbic9gHZwknpTCv4oeKp=w1200-h630-p-k-no-nu "Contoh literature review proposal skripsi")

<small>hotpressnyc.blogspot.com</small>

Entitas erd diktat. Contoh jurnal qualitative research pdf

## 42+ Contoh Jurnal Inovasi Pendidikan Budaya Pics - File File Guru

![42+ Contoh Jurnal Inovasi Pendidikan Budaya Pics - File File Guru](https://blog-static.mamikos.com/wp-content/uploads/2021/03/Jurnal-Pendidikan.jpg "Contoh jurnal bahasa inggris tentang reading pdf – berbagai contoh")

<small>filefileguru.blogspot.com</small>

Contoh resume jurnal pendidikan. Contoh jurnal bahasa inggris tentang reading pdf – berbagai contoh

## Contoh Metode Penelitian Gabungan / Hasil Belajar Matematika Siswa Pdf

![Contoh Metode Penelitian Gabungan / Hasil Belajar Matematika Siswa Pdf](https://lh5.googleusercontent.com/proxy/ZKxwQTSxfzyZbISaVILUTjsUqKrNWQpQMCBDKA3cZLp5FiRiGY5fWdltOS1C9I5-rS2Wwlrcz0CiOxL6aMUn2OLpDTAD8mFMY3Qhyr7Kn4Fwh_j19kWUYpBGhq3Mn1ssyitTHgZImIXIXQ3NxyiCLKgW0c3mS6Y38S2X76hUGzpfNBis7yeMyENS=w1200-h630-p-k-no-nu "Contoh literature review proposal skripsi")

<small>downloadmateridance.blogspot.com</small>

Qualitative sample khmer. Kasim jurnal qualitative

## Contoh Jurnal Qualitative Research Pdf - Contoh Diam

![Contoh Jurnal Qualitative Research Pdf - Contoh Diam](https://lh5.googleusercontent.com/proxy/g8ZXi5fYdouBkwHlMBa7YQc2fqPH7olZ5Bxm_rkPM0cHt6HD9lJiAjTDUZAjM4FdORhGCZ7Cv3hpQ9Ubpg0FwjQMDVE5npbUMnuhbFmfh3E2PBkIb_lSmMxwNmuliwJaoED2KNLRYj15N89p-i8yQCtmXDePDGP1Bp-ZPfrGuSJlDtXDD-ZuGpMnrCiGy824a76HKrvH8ptDaN3EvkXUX8BUs1A-=w1200-h630-p-k-no-nu "(pdf) pemahaman mahasiswa atas metode penelitian kualitatif: sebuah")

<small>contohdiam.blogspot.com</small>

Jurnal penelitian pemodelan forecasting saintek. Contoh jurnal qualitative research pdf

## Contoh Jurnal Qualitative Research - Lowongan Kerja Terbaru

![Contoh Jurnal Qualitative Research - Lowongan Kerja Terbaru](https://lh3.googleusercontent.com/proxy/qTl1N4FFF4n4eysIgrXKnK0yCelo0sCv0jQak00sK4VM3q3KiPYncqR5hhVpQ3wm1yPTsg_WoOdt-JnIx5rfFAtKZCtHN9T-TyzeRVRbyonwAGe0bJLDjHPjpoDkjq4IadtsOkSPlzI_otekX8bbpVLuQCggJPJX4AWSK7Cerntt1h1-EQHTm7Bg0x5zWKtzx5i2YvIn-3YsvhqEiwyoO94=w1200-h630-p-k-no-nu "Penelitian kualitatif skripsi")

<small>kerja7.blogspot.com</small>

Jurnal hubungan studylibid prodi. Surat waris ahli anak hukum keterangan kawin luar dari kekuatan bagi pernikahan tidak

## (PDF) Kekuatan Hukum Surat Keterangan Ahli Waris Bagi Anak Luar Kawin

![(PDF) Kekuatan Hukum Surat Keterangan Ahli Waris Bagi Anak Luar Kawin](https://i1.rgstatic.net/publication/322575601_Kekuatan_Hukum_Surat_Keterangan_Ahli_Waris_Bagi_Anak_Luar_Kawin_dari_Pernikahan_Tidak_Tercatat/links/5b6f530245851546c9fb78d6/largepreview.png "Penelitian kualitatif pdf contoh")

<small>www.researchgate.net</small>

Qualitative sample khmer. Penelitian qualitative

## Contoh Jurnal Qualitative Research Pdf - Contoh Grim

![Contoh Jurnal Qualitative Research Pdf - Contoh Grim](https://i1.rgstatic.net/publication/259611840_Mixture_model_approach_to_the_analysis_of_heterogeneous_survival_data/links/53e352120cf2b9d0d8332ae9/largepreview.png "Quantitative qualitative jurnal")

<small>contohgrim.blogspot.com</small>

Contoh jurnal qualitative research pdf. Contoh resume jurnal pendidikan

## Jurnal Kualitatif | Qualitative Research | Data Analysis | Free 30-day

![Jurnal Kualitatif | Qualitative Research | Data Analysis | Free 30-day](https://imgv2-1-f.scribdassets.com/img/document/305996029/original/e7dbf0e714/1590246228?v=1 "Quantitative qualitative jurnal")

<small>www.scribd.com</small>

Penelitian kualitatif skripsi. Aspek haeri menelaah

## Contoh Literature Review Proposal Skripsi - Contoh Gil

![Contoh Literature Review Proposal Skripsi - Contoh Gil](https://lh5.googleusercontent.com/proxy/veHlOVfG_bBTNhqPg4C3NK3InicAdMcLmqW9ztDgxhK_im4ziotNK1zOC3RZX62xAL-4XNTclfoMnqD0CYjQQ3tmE1XzZO6AqwQIAxXQ-PQMJ65ck65lqy5Xr1XX8jbidloI4t8o8VoFKZn5DpC2ZlTv555YqANJg8UNXetZJ4fpOVSMglUyEu-n8_w=w1200-h630-p-k-no-nu "Kasim jurnal qualitative")

<small>contohgil.blogspot.com</small>

Penelitian qualitative. Jurnal pendidikan

## Contoh Jurnal Qualitative Research Pdf - 600 Tips

![Contoh Jurnal Qualitative Research Pdf - 600 Tips](https://image.slidesharecdn.com/quantitative-150513104146-lva1-app6891/95/an-example-of-a-quantitative-research-design-1-638.jpg?cb=1431513762 "Jurnal qualitative unduh dokumen")

<small>600tips.blogspot.com</small>

Contoh jurnal bahasa inggris tentang reading pdf – berbagai contoh. Jurnal pendidikan

## Contoh Jurnal Bahasa Inggris Tentang Reading Pdf – Berbagai Contoh

![Contoh Jurnal Bahasa Inggris Tentang Reading Pdf – Berbagai Contoh](https://i1.rgstatic.net/publication/323173426_AN_ANALYSIS_OF_THE_STUDENTS&#039;_READING_COMPREHENSION_IN_COMPREHENDING_DESCRIPTIVE_TEXT/links/5a843dc7a6fdcc201b9ec6d2/largepreview.png "Contoh jurnal qualitative research pdf")

<small>berbagaicontoh.com</small>

Contoh jurnal qualitative research pdf. Surat waris ahli anak hukum keterangan kawin luar dari kekuatan bagi pernikahan tidak

## (PDF) Pola Pikir Penggunaan Bahasa Inggris Pada Masyarakat Perkotaan Di

![(PDF) Pola Pikir Penggunaan Bahasa Inggris Pada Masyarakat Perkotaan di](https://i1.rgstatic.net/publication/334364676_Pola_Pikir_Penggunaan_Bahasa_Inggris_Pada_Masyarakat_Perkotaan_di_Jabodetabek/links/5d2604f1a6fdcc2462d32327/largepreview.png "Jurnal mamikos inovasi budaya")

<small>www.researchgate.net</small>

(pdf) kekuatan hukum surat keterangan ahli waris bagi anak luar kawin. Contoh jurnal qualitative research pdf

## Contoh Skripsi Kualitatif Pdf To Word Inseomxseo

![Contoh Skripsi Kualitatif Pdf To Word Inseomxseo](https://imgv2-1-f.scribdassets.com/img/document/358384800/original/29a13ba890/1529564090?v=1 "Quantitative qualitative jurnal")

<small>kumpuancontohsoalpopuler34.blogspot.com</small>

Jurnal inggris. Kualitatif penelitian jurnal metode inggris artikel skripsi kuantitatif refleksi pembelajaran pemahaman judul

## Penelitian Kualitatif Pdf Contoh | Jurnal Doc

![Penelitian Kualitatif Pdf Contoh | Jurnal Doc](https://0.academia-photos.com/attachment_thumbnails/34815633/mini_magick20180816-3671-uvxpy0.png?1534462779 "Cerpen diksi karya rangkuti kesetiaan materi sma")

<small>jurnal-doc.com</small>

Contoh resume jurnal pendidikan. Contoh skripsi kualitatif pdf to word inseomxseo

## Contoh Resume Jurnal Pendidikan - Gerotoh

![Contoh Resume Jurnal Pendidikan - Gerotoh](https://image.slidesharecdn.com/diktatsistembasisdata-150415042007-conversion-gate01/95/diktat-sistem-basis-data-29-638.jpg?cb=1429071797 "Contoh jurnal qualitative research pdf")

<small>gerotoh.blogspot.com</small>

Jurnal qualitative unduh dokumen. Contoh metode penelitian gabungan / hasil belajar matematika siswa pdf

## Jurnal Pendidikan | Classroom | Qualitative Research

![jurnal pendidikan | Classroom | Qualitative Research](https://imgv2-1-f.scribdassets.com/img/document/220925433/original/6ce35e47ce/1587995559?v=1 "Jurnal komunikasi")

<small>www.scribd.com</small>

Penelitian kualitatif skripsi. Contoh literature review proposal skripsi

## Contoh Jurnal Qualitative Research Pdf - Contoh Grim

![Contoh Jurnal Qualitative Research Pdf - Contoh Grim](https://lh5.googleusercontent.com/proxy/uHmaKUFmqjGa6gYTlzZUI8eSSEgeuYHhxBYNA1mj9F-pd7rYUYmlmKncmBeeB5xeKFOdm6goOxcLpDnz2JteQ8IdBUAbbH83TrDgSPgVTpsfIBt_A9iqWyTcQoUs736MryrLUueaTKj8Sbz8FV2nBCFfTFQe56Mp2qALyHSU6TwOLg=s0-d "Qualitative sample khmer")

<small>contohgrim.blogspot.com</small>

Quantitative qualitative jurnal. Contoh jurnal bahasa inggris tentang reading pdf – berbagai contoh

## Contoh Proposal Qualitative Research Pendidikan Bahasa Inggris

![Contoh Proposal Qualitative Research Pendidikan Bahasa Inggris](https://lh3.googleusercontent.com/proxy/DujJP_XZ8Tvw1Jh-3kYwbx__vJFwjI8LZYiCuYVqoUU_RDDz1uAX2bGkCLkKf4a7Jn9kMASAz0SMszd9ri1u_xcQw3SjUByPBgvklEs0V30ErzcYlFhWknxVAoTZtbk=s0-d "Contoh resume jurnal pendidikan")

<small>contohproposalnew.blogspot.com</small>

Contoh jurnal akuntansi pdf. (pdf) jurnal komunikasi

## (PDF) MANAJEMEN KEUANGAN SEKOLAH DALAM PEMENUHAN SARANA PRASARANA

![(PDF) MANAJEMEN KEUANGAN SEKOLAH DALAM PEMENUHAN SARANA PRASARANA](https://i1.rgstatic.net/publication/340666876_MANAJEMEN_KEUANGAN_SEKOLAH_DALAM_PEMENUHAN_SARANA_PRASARANA_PENDIDIKAN_Studi_kasus_di_SD_Muhammadiyah_1_Krian_Sidoarjo/links/5e986413a6fdcca7891e6d8c/largepreview.png "Contoh jurnal akuntansi pdf")

<small>www.researchgate.net</small>

Contoh skripsi kualitatif pdf to word inseomxseo. Contoh jurnal qualitative research pdf

## Contoh Jurnal Akuntansi Pdf - Footlasopa

![Contoh Jurnal Akuntansi Pdf - footlasopa](https://imgv2-1-f.scribdassets.com/img/document/329379235/149x198/ce86eafaa8/1543807896?v=1 "Contoh jurnal qualitative research pdf")

<small>footlasopa198.weebly.com</small>

Methodology qualitative quantitative dissertation ihelptostudy hypothesis brojsimpson. (pdf) gaya bahasa dan diksi dalam kumpulan cerpen kesetiaan itu karya

## Contoh Proposal Qualitative Research - VRasmi

![Contoh Proposal Qualitative Research - VRasmi](https://lh3.googleusercontent.com/proxy/ntJ_zPYsTiwhuMHg7Exf6WCIihTXy1Fu7CcsywMyqB29MebMOW2tzTsfgVj4I4e4jdSxoTUQMJXG6hasmQb3sKX5GfV2spubgdh2KKvzYnsuTL1fzr4fHRnVYnvI2RTegGS0-4uJVN0Zxelns2NHrw=s0-d "Quantitative qualitative jurnal")

<small>vrasmi.blogspot.com</small>

Inklusi administrasi. Qualitative quantitative exploratory proposal

## (PDF) GAYA BAHASA DAN DIKSI DALAM KUMPULAN CERPEN KESETIAAN ITU KARYA

![(PDF) GAYA BAHASA DAN DIKSI DALAM KUMPULAN CERPEN KESETIAAN ITU KARYA](https://i1.rgstatic.net/publication/341275874_GAYA_BAHASA_DAN_DIKSI_DALAM_KUMPULAN_CERPEN_KESETIAAN_ITU_KARYA_HAMSAD_RANGKUTI_SEBAGAI_MATERI_PEMBELAJARAN_BAHASA_INDONESIA_DI_SMA/links/5eb76571299bf1287f781471/largepreview.png "42+ contoh jurnal inovasi pendidikan budaya pics")

<small>www.researchgate.net</small>

Contoh skripsi kualitatif pdf to word inseomxseo. Kasim jurnal qualitative

## Contoh Proposal Qualitative Research - Contoh Kono

![Contoh Proposal Qualitative Research - Contoh Kono](https://lh3.googleusercontent.com/proxy/CMFdsKmhJrYQveeqyHuBJwxVSuuy36ZkfZekUrcBgkhZ4TmAYZQcvAiPfQFp7vz-OYULFc-LmFm7NigJhkkErTM7AoyZAHpM7Gtw7qvY_nmerPPqo-8P2jMSaU_dTG4AbmJwF-XYHL_9DhJy17VdMUQ-QrLXJ1hyH-Si28UBdkfM7bW-vR2B7z3G10Jf8yafa8mqD2YIl_5vC23sDhGumaxuEFLZhrb1JzfxlQkkNCr-FWla0HtcCmtarVUiDzIajlgqSXQF4_0lFVrD--VEu7hSVGY2ULh8bHUQqY2du1LKZaaPMcYkGtOtqg4RcgZlF3VeXa_eXUmECBo_krSX_PKv=w1200-h630-p-k-no-nu "42+ contoh jurnal inovasi pendidikan budaya pics")

<small>contohkono.blogspot.com</small>

(pdf) jurnal komunikasi. Methodology qualitative quantitative dissertation ihelptostudy hypothesis brojsimpson

## Contoh Jurnal Qualitative Research Pdf - Contoh Diam

![Contoh Jurnal Qualitative Research Pdf - Contoh Diam](https://image.slidesharecdn.com/modulteknikkasimmendeley2-150222004549-conversion-gate01/95/modul-teknik-kasimmendeley2-18-638.jpg?cb=1424587614 "Imrad examples / imrad format example pdf contoh makalah : many")

<small>contohdiam.blogspot.com</small>

Qualitative quantitative exploratory proposal. Surat waris ahli anak hukum keterangan kawin luar dari kekuatan bagi pernikahan tidak

## Contoh Jurnal Bahasa Inggris Tentang Reading Pdf – Berbagai Contoh

![Contoh Jurnal Bahasa Inggris Tentang Reading Pdf – Berbagai Contoh](https://imgv2-2-f.scribdassets.com/img/document/170269520/298x396/c237c6492e/1569284311?v=1 "Jurnal inggris")

<small>berbagaicontoh.com</small>

(pdf) kekuatan hukum surat keterangan ahli waris bagi anak luar kawin. Penelitian kualitatif skripsi

## Contoh Proposal Qualitative Research Pendidikan Bahasa Inggris

![Contoh Proposal Qualitative Research Pendidikan Bahasa Inggris](https://lh6.googleusercontent.com/proxy/CiVyoxULdtgYoIDp1hy4jPyokuWRvld64vLZwdHGCwI4YUHe5Ds1Idydt2S-wzUAjHN4Lsr-37jFTiAiEzJMsvOwN_KgneomaGvRYPbWdjnI6oooUYh_Jkyzf__xIg=s0-d "Contoh jurnal qualitative research pdf")

<small>contohproposalnew.blogspot.com</small>

Kasim jurnal qualitative. Imrad examples / imrad format example pdf contoh makalah : many

Jurnal mamikos inovasi budaya. (pdf) pola pikir penggunaan bahasa inggris pada masyarakat perkotaan di. Penelitian qualitative
